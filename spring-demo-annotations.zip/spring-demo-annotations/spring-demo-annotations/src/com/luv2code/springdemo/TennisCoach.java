package com.luv2code.springdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component()
public class TennisCoach implements Coach {
    private FortuneService fortuneService;
//    @Autowired
//    public TennisCoach(FortuneService theFortuneService)
//    {
//    	fortuneService= theFortuneService;
//    }
    // define a default constructor
    public TennisCoach() {
    	System.out.println("inside Default constructor");
    }
    // define setter method
    @Autowired
    public void setFortuneService(FortuneService theFortuneService) {
    	System.out.println("inside Setter method");
    	fortuneService = theFortuneService;
    }
	@Override
	public String getDailyWorkout() {
		System.out.println("Inside Tennis Coach");
		return "Practice your backend volley";
	}

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return fortuneService.getFortune();
	}

}
